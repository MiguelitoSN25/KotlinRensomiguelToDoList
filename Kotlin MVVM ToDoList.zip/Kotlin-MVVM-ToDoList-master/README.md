Kotlin-MVVM-ToDoList

YouTube
https://www.youtube.com/playlist?list=PLoCYbRS6dPkJMThvLiPEaWGQ0tV2XL4v8
